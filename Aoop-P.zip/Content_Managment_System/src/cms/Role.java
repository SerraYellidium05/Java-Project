package cms;

public enum Role {
    ADMIN,EDITOR,VIEWER
}