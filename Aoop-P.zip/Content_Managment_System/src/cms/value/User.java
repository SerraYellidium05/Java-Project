package cms.value;
import cms.Role;

public record User() {

	public Role getRole1() {
		// TODO Auto-generated method stub
		return null;
	}
}
	