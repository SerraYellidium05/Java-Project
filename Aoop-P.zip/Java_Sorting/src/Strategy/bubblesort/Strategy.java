package Strategy.bubblesort;

public @interface Strategy {

}
