/**
 * 
 */
/**
 * 
 */
module Java_Sorting {
	requires org.junit.jupiter.api;
}